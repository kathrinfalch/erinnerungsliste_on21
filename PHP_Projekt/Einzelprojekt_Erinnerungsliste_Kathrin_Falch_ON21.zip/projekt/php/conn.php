<?php

    $db_host = "db";
    $db_user = "kathrin";
    $db_passwort = "kathrinphp";
    $db_name = "erinnerungsliste_kathrinphp";

    $sql = new MySQLi($db_host, $db_user, $db_passwort, $db_name);  
?>